Name: Asteroid Juggling

Objective: Asteroids are bombarding Earth, and to defend Earth, we have strapped rockets to the moon to wack them away. Keep asteroids from hitting the Earth - and don't lose control of the moon either, because it'll be even worse!

Controls: Hold left click to attract the moon to your mouse cursor.